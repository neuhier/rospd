# rosdp
R Package to Generate Optimal (Semi-) Split Plot Designs
