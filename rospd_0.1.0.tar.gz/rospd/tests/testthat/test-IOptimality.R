context("I Optimality")

# testthat("I Optimality is calculated correctly",{
#   
# })